# =============================================================
# main.py
# Entry point — runs the full ML pipeline end to end:
#   1. Preprocess data
#   2. Train model
#   3. Evaluate model
#   4. Save visualizations
#   5. Predict for new patients
# =============================================================

from preprocess import preprocess
from model import (
    split_data,
    train_model,
    evaluate_model,
    plot_confusion_matrix,
    plot_feature_importance,
    plot_metrics_chart,
    plot_decision_tree,
    predict_new_patient
)


def main():
    print("\n🏥 Early Prediction of Late-Onset Neonatal Sepsis")
    print("   Using Decision Tree Classifier")
    print("=" * 45)

    # ── STEP 1–4: Preprocess ──────────────────────────────
    X, y, scaler, selector, selected_features, all_features = preprocess()

    # ── STEP 5: Train/Test Split ──────────────────────────
    X_train, X_test, y_train, y_test = split_data(X, y)

    # ── STEP 6: Train Model ───────────────────────────────
    model = train_model(X_train, y_train)

    # ── STEP 7: Evaluate ──────────────────────────────────
    y_pred, metrics = evaluate_model(model, X_test, y_test)

    # ── STEP 8: Save Visualizations ───────────────────────
    print("\n📁 Saving visualizations to outputs/...")
    plot_confusion_matrix(y_test, y_pred)
    plot_feature_importance(model, selected_features)
    plot_metrics_chart(metrics)
    plot_decision_tree(model, selected_features)

    # ── STEP 9: Predict for New Patients ──────────────────
    print("\n🔬 Running predictions for new patients...\n")

    # Test Case 1: High-risk neonate
    high_risk = {
        'Temperature':      38.9,
        'Heart_Rate':       175,
        'Respiratory_Rate': 68,
        'WBC_Count':        22.0,
        'CRP_Level':        48.0,
        'Blood_Glucose':    35.0,
        'Gestational_Age':  29.0,
        'Birth_Weight':     1100.0
    }
    print("--- Test Case 1: High-Risk Neonate ---")
    predict_new_patient(model, scaler, selector, selected_features, all_features, high_risk)

    # Test Case 2: Low-risk neonate
    low_risk = {
        'Temperature':      37.1,
        'Heart_Rate':       138,
        'Respiratory_Rate': 44,
        'WBC_Count':        10.5,
        'CRP_Level':        4.0,
        'Blood_Glucose':    65.0,
        'Gestational_Age':  39.0,
        'Birth_Weight':     3200.0
    }
    print("\n--- Test Case 2: Low-Risk Neonate ---")
    predict_new_patient(model, scaler, selector, selected_features, all_features, low_risk)

    print("\n✅ All done! Check the outputs/ folder for saved charts.\n")


if __name__ == "__main__":
    main()
