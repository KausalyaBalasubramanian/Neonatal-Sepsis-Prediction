# 🏥 Early Prediction of Late-Onset Neonatal Sepsis
### Using Decision Tree Classifier | Python ML Mini Project

---

## 📌 Project Overview

This project predicts whether a neonate (newborn) is at risk of **Late-Onset Neonatal Sepsis (LONS)** using clinical features and a **Decision Tree Classifier**.

> ⚠️ This is a student/educational project using a **synthetic dataset**.  
> It is **not** intended for real clinical use.

---

## 📁 Project Structure

```
neonatal_sepsis_predictor/
│
├── main.py            ← Run this file to start the project
├── preprocess.py      ← Data generation, cleaning, normalization, feature selection
├── model.py           ← Model training, evaluation, prediction, visualizations
├── requirements.txt   ← Python packages needed
├── README.md          ← This file
│
└── outputs/           ← Auto-created folder; charts saved here
    ├── confusion_matrix.png
    ├── feature_importance.png
    ├── metrics_chart.png
    └── decision_tree.png
```

---

## ⚙️ Features Used

| Feature          | Description                  | Unit        |
|------------------|------------------------------|-------------|
| Temperature      | Body temperature             | °C          |
| Heart_Rate       | Heart beats per minute       | bpm         |
| Respiratory_Rate | Breaths per minute           | breaths/min |
| WBC_Count        | White blood cell count       | ×10⁹/L      |
| CRP_Level        | C-Reactive Protein level     | mg/L        |
| Blood_Glucose    | Blood sugar level            | mg/dL       |
| Gestational_Age  | Age at birth                 | weeks       |
| Birth_Weight     | Weight at birth              | grams       |

**Target:** `Sepsis` → `1 = Positive`, `0 = Negative`

---

## 🚀 How to Run

### Step 1 — Make sure Python is installed
```bash
python --version
# Should be Python 3.7 or above
```

### Step 2 — Install required packages
```bash
pip install -r requirements.txt
```

### Step 3 — Run the project
```bash
python main.py
```

That's it! The program will automatically:
- Generate the dataset
- Clean and normalize the data
- Select the top 5 features
- Train the Decision Tree model
- Print evaluation results
- Save 4 charts to the `outputs/` folder
- Predict for 2 sample patients

---

## 📊 Expected Output

```
🏥 Early Prediction of Late-Onset Neonatal Sepsis
   Using Decision Tree Classifier
=============================================
  PREPROCESSING PIPELINE
=============================================
[1] Dataset generated       : 500 rows, 9 columns
    Sepsis rate             : ~35%
[2] Missing values fixed     : 75 filled with median
[3] Normalization applied    : StandardScaler (mean=0, std=1)
[4] Features selected (top5) : ['CRP_Level', 'WBC_Count', ...]
[5] Train/Test split         : 400 train | 100 test
[6] Model trained            : DecisionTree (depth=4, leaves=...)

=============================================
        MODEL EVALUATION RESULTS
=============================================
  Accuracy  : ~0.89  (89.0%)
  Precision : ~0.87
  Recall    : ~0.85
  F1-Score  : ~0.86
=============================================

📁 Saving visualizations to outputs/...
  📊 Saved: outputs/confusion_matrix.png
  📊 Saved: outputs/feature_importance.png
  📊 Saved: outputs/metrics_chart.png
  📊 Saved: outputs/decision_tree.png

⚠️  Result  : SEPSIS POSITIVE   ← High-risk patient
✅ Result  : SEPSIS NEGATIVE   ← Low-risk patient
```

---

## 🧠 ML Pipeline Summary

```
Raw Data → Handle Missing Values → Normalize → Feature Selection
       → Train/Test Split → Decision Tree → Evaluate → Predict
```

---

## 🛠️ Customize the Project

**Change number of training samples:**  
In `preprocess.py` → `generate_dataset(n_samples=500)`

**Change tree depth:**  
In `model.py` → `DecisionTreeClassifier(max_depth=4)`

**Change number of selected features:**  
In `preprocess.py` → `select_features(X, y, k=5)`

**Predict for your own patient:**  
In `main.py`, add a new dictionary under Step 9 and call `predict_new_patient(...)`.

---

## 📦 Dependencies

| Package      | Purpose                          |
|--------------|----------------------------------|
| numpy        | Numerical operations             |
| pandas       | Data handling                    |
| scikit-learn | ML model, preprocessing, metrics |
| matplotlib   | Plotting charts                  |
| seaborn      | Heatmap (confusion matrix)       |

---

*Built as a Final Year Student ML Mini Project*
