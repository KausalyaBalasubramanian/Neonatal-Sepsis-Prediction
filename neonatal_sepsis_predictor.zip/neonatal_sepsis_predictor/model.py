# =============================================================
# model.py
# Handles: Model training, evaluation, prediction, visualization
# =============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend (works without a display)

from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report
)
import seaborn as sns
import os


# --- Output folder for saving plots ---
OUTPUT_DIR = "outputs"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def split_data(X, y, test_size=0.2, random_state=42):
    """
    Splits data into training and testing sets (80/20).
    stratify=y ensures balanced class distribution in both sets.
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=test_size,
        random_state=random_state,
        stratify=y
    )
    print(f"[5] Train/Test split         : {X_train.shape[0]} train | {X_test.shape[0]} test")
    return X_train, X_test, y_train, y_test


def train_model(X_train, y_train):
    """
    Trains a Decision Tree Classifier.
    max_depth=4 prevents overfitting and keeps the tree readable.
    """
    model = DecisionTreeClassifier(
        max_depth=4,       # Limit depth to avoid overfitting
        criterion='gini',  # Gini impurity for node splitting
        random_state=42
    )
    model.fit(X_train, y_train)
    print(f"[6] Model trained            : DecisionTree (depth={model.get_depth()}, leaves={model.get_n_leaves()})")
    return model


def evaluate_model(model, X_test, y_test):
    """
    Evaluates the model and prints all key metrics.
    Returns predictions.
    """
    y_pred = model.predict(X_test)

    accuracy  = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall    = recall_score(y_test, y_pred)
    f1        = f1_score(y_test, y_pred)

    print("\n" + "=" * 45)
    print("        MODEL EVALUATION RESULTS")
    print("=" * 45)
    print(f"  Accuracy  : {accuracy:.4f}  ({accuracy*100:.1f}%)")
    print(f"  Precision : {precision:.4f}")
    print(f"  Recall    : {recall:.4f}")
    print(f"  F1-Score  : {f1:.4f}")
    print("=" * 45)
    print("\n📋 Full Classification Report:")
    print(classification_report(y_test, y_pred,
          target_names=['No Sepsis (0)', 'Sepsis (1)']))

    return y_pred, (accuracy, precision, recall, f1)


def plot_confusion_matrix(y_test, y_pred):
    """Saves a confusion matrix heatmap to outputs/."""
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['No Sepsis', 'Sepsis'],
                yticklabels=['No Sepsis', 'Sepsis'])
    plt.title('Confusion Matrix', fontsize=13, fontweight='bold')
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "confusion_matrix.png")
    plt.savefig(path, dpi=120)
    plt.close()
    print(f"  📊 Saved: {path}")


def plot_feature_importance(model, selected_features):
    """Saves a horizontal bar chart of feature importances to outputs/."""
    importances = model.feature_importances_
    feat_df = pd.DataFrame({
        'Feature': selected_features,
        'Importance': importances
    }).sort_values('Importance', ascending=True)

    plt.figure(figsize=(7, 4))
    plt.barh(feat_df['Feature'], feat_df['Importance'],
             color='steelblue', edgecolor='black')
    plt.title('Feature Importance (Decision Tree)', fontsize=13, fontweight='bold')
    plt.xlabel('Importance Score')
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "feature_importance.png")
    plt.savefig(path, dpi=120)
    plt.close()
    print(f"  📊 Saved: {path}")


def plot_metrics_chart(metrics):
    """Saves a bar chart of accuracy, precision, recall, F1 to outputs/."""
    labels = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
    colors = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0']

    plt.figure(figsize=(7, 4))
    bars = plt.bar(labels, metrics, color=colors, edgecolor='black', width=0.5)
    plt.ylim(0, 1.1)
    plt.title('Model Performance Metrics', fontsize=13, fontweight='bold')
    plt.ylabel('Score')
    for bar, val in zip(bars, metrics):
        plt.text(bar.get_x() + bar.get_width() / 2,
                 bar.get_height() + 0.02,
                 f'{val:.3f}', ha='center', fontsize=11)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "metrics_chart.png")
    plt.savefig(path, dpi=120)
    plt.close()
    print(f"  📊 Saved: {path}")


def plot_decision_tree(model, selected_features):
    """Saves a visualization of the decision tree to outputs/."""
    plt.figure(figsize=(18, 8))
    plot_tree(model,
              feature_names=selected_features,
              class_names=['No Sepsis', 'Sepsis'],
              filled=True, rounded=True, fontsize=9)
    plt.title('Decision Tree Structure', fontsize=14, fontweight='bold')
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "decision_tree.png")
    plt.savefig(path, dpi=100)
    plt.close()
    print(f"  📊 Saved: {path}")


def predict_new_patient(model, scaler, selector, selected_features, all_features, patient_data):
    """
    Predicts sepsis risk for a new patient given raw clinical values.

    Parameters:
        patient_data (dict): Raw clinical values with all 8 feature keys
    """
    import pandas as pd

    input_df     = pd.DataFrame([patient_data])
    input_scaled = scaler.transform(input_df[all_features])
    input_scaled = pd.DataFrame(input_scaled, columns=all_features)
    input_final  = input_scaled[selected_features]

    prediction   = model.predict(input_final)[0]
    probability  = model.predict_proba(input_final)[0]

    print("\n" + "=" * 42)
    print("        SEPSIS PREDICTION RESULT")
    print("=" * 42)
    print(f"  Patient Input : {patient_data}")
    print("-" * 42)
    if prediction == 1:
        print("  ⚠️  Result  : SEPSIS POSITIVE")
        print("  ❗ Immediate clinical attention advised.")
    else:
        print("  ✅ Result  : SEPSIS NEGATIVE")
        print("  🟢 No immediate sepsis risk detected.")
    print(f"\n  Confidence:")
    print(f"    No Sepsis : {probability[0]*100:.1f}%")
    print(f"    Sepsis    : {probability[1]*100:.1f}%")
    print("=" * 42)

    return prediction
