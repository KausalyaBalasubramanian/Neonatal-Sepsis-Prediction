# =============================================================
# preprocess.py
# Handles: Dataset generation, missing values, normalization,
#          feature selection
# =============================================================

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_classif


def generate_dataset(n_samples=500, random_state=42):
    """
    Generates a synthetic neonatal sepsis dataset.
    Returns a pandas DataFrame.
    """
    np.random.seed(random_state)

    # --- Clinical feature generation ---
    temperature       = np.random.normal(37.0, 0.8, n_samples)
    heart_rate        = np.random.normal(140, 20, n_samples)
    respiratory_rate  = np.random.normal(45, 10, n_samples)
    wbc_count         = np.random.normal(12, 5, n_samples)
    crp_level         = np.random.exponential(scale=15, size=n_samples)
    blood_glucose     = np.random.normal(60, 15, n_samples)
    gestational_age   = np.random.randint(28, 43, n_samples).astype(float)
    birth_weight      = np.random.normal(2500, 700, n_samples)

    # --- Label generation based on clinical logic ---
    sepsis_score = (
        (crp_level > 20).astype(int) * 2 +
        (wbc_count > 18).astype(int) * 2 +
        (temperature > 38.0).astype(int) +
        (temperature < 36.0).astype(int) +
        (heart_rate > 160).astype(int) +
        (respiratory_rate > 60).astype(int) +
        (gestational_age < 34).astype(int) +
        (birth_weight < 1500).astype(int)
    )
    sepsis_label = (sepsis_score >= 3).astype(int)

    df = pd.DataFrame({
        'Temperature':      temperature,
        'Heart_Rate':       heart_rate,
        'Respiratory_Rate': respiratory_rate,
        'WBC_Count':        wbc_count,
        'CRP_Level':        crp_level,
        'Blood_Glucose':    blood_glucose,
        'Gestational_Age':  gestational_age,
        'Birth_Weight':     birth_weight,
        'Sepsis':           sepsis_label
    })

    # Introduce ~5% missing values in 3 columns (simulates real-world data)
    for col in ['WBC_Count', 'CRP_Level', 'Blood_Glucose']:
        missing_idx = np.random.choice(df.index, size=25, replace=False)
        df.loc[missing_idx, col] = np.nan

    return df


def handle_missing_values(df):
    """
    Fills missing values with column median.
    Median is used because it is robust to outliers.
    """
    df = df.fillna(df.median(numeric_only=True))
    return df


def normalize_features(X):
    """
    Scales features to mean=0, std=1 using StandardScaler.
    Returns scaled DataFrame and the fitted scaler object.
    """
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_scaled = pd.DataFrame(X_scaled, columns=X.columns)
    return X_scaled, scaler


def select_features(X, y, k=5):
    """
    Selects top K features using ANOVA F-test (f_classif).
    Returns selected DataFrame, selector object, and selected feature names.
    """
    selector = SelectKBest(score_func=f_classif, k=k)
    selector.fit(X, y)

    selected_mask     = selector.get_support()
    selected_features = [f for f, m in zip(X.columns, selected_mask) if m]
    X_selected        = X[selected_features]

    return X_selected, selector, selected_features


def preprocess(verbose=True):
    """
    Master function that runs the full preprocessing pipeline.
    Returns everything needed for model training and prediction.
    """
    if verbose:
        print("=" * 45)
        print("  PREPROCESSING PIPELINE")
        print("=" * 45)

    # Step 1: Generate data
    df = generate_dataset()
    if verbose:
        print(f"[1] Dataset generated       : {df.shape[0]} rows, {df.shape[1]} columns")
        print(f"    Sepsis rate             : {df['Sepsis'].mean()*100:.1f}%")

    # Step 2: Handle missing values
    missing_before = df.isnull().sum().sum()
    df = handle_missing_values(df)
    if verbose:
        print(f"[2] Missing values fixed     : {missing_before} filled with median")

    # Step 3: Split features and target
    X = df.drop('Sepsis', axis=1)
    y = df['Sepsis']

    # Step 4: Normalize
    X_scaled, scaler = normalize_features(X)
    if verbose:
        print(f"[3] Normalization applied    : StandardScaler (mean=0, std=1)")

    # Step 5: Feature selection
    X_final, selector, selected_features = select_features(X_scaled, y, k=5)
    if verbose:
        print(f"[4] Features selected (top5) : {selected_features}")
        print("=" * 45)

    return X_final, y, scaler, selector, selected_features, X.columns.tolist()
